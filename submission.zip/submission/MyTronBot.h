#ifndef MYTRONBOT_H
#define MYTRONBOT_H

#include <iostream>
#include <fstream>

extern std::ofstream logfile;

// Tron data types
enum Player {Me, Them};


#endif